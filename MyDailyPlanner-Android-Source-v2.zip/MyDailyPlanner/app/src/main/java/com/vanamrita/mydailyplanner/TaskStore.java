package com.vanamrita.mydailyplanner;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

class TaskStore {
    static final String PREF="planner_data", KEY="tasks";
    static List<JSONObject> all(Context c) {
        ArrayList<JSONObject> out=new ArrayList<>();
        try { JSONArray a=c.getSharedPreferences(PREF,0).getJSONArray(KEY); for(int i=0;i<a.length();i++) out.add(a.getJSONObject(i)); } catch(Exception ignored) {}
        return out;
    }
    static void save(Context c,List<JSONObject> tasks) {
        JSONArray a=new JSONArray(); for(JSONObject o:tasks) a.put(o);
        c.getSharedPreferences(PREF,0).edit().putString(KEY,a.toString()).apply();
    }
    static JSONObject find(Context c,String id) { for(JSONObject o:all(c)) if(o.optString("id").equals(id)) return o; return null; }
    static void put(Context c,JSONObject task) {
        List<JSONObject> a=all(c); boolean replaced=false;
        for(int i=0;i<a.size();i++) if(a.get(i).optString("id").equals(task.optString("id"))){a.set(i,task);replaced=true;break;}
        if(!replaced)a.add(task); save(c,a);
    }
}
