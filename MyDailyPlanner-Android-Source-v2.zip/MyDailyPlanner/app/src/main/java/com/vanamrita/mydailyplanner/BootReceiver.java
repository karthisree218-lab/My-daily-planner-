package com.vanamrita.mydailyplanner;
import android.content.*;import org.json.JSONObject;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){for(JSONObject t:TaskStore.all(c)){if(!t.optBoolean("done")){long at=t.optLong("when",0);if(at>0)AlarmScheduler.schedule(c,t.optString("id"),Math.max(at,System.currentTimeMillis()+5000));}}}
}
