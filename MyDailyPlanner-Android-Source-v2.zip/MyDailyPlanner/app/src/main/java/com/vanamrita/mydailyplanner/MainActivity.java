package com.vanamrita.mydailyplanner;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Typeface;import android.view.*;import android.widget.*;
import org.json.JSONObject;import java.text.*;import java.util.*;

public class MainActivity extends Activity {
 LinearLayout root,list; EditText title; TextView heading,summary; Calendar chosen=Calendar.getInstance(); boolean english=true;
 int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
 TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xff182230);return t;}
 @Override public void onCreate(Bundle b){super.onCreate(b);requestPermissionsIfNeeded();build();}
 void requestPermissionsIfNeeded(){if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10);if(Build.VERSION.SDK_INT>=31){try{AlarmManager a=(AlarmManager)getSystemService(ALARM_SERVICE);if(!a.canScheduleExactAlarms()){Intent x=new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);startActivity(x);}}catch(Exception ignored){}}}
 void build(){
  ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(18),dp(24),dp(18),dp(24));root.setBackgroundColor(0xfff6f8fb);sc.addView(root);setContentView(sc);
  LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);heading=text("My Daily Planner",25);heading.setTypeface(null,Typeface.BOLD);top.addView(heading,new LinearLayout.LayoutParams(0,-2,1));Button lang=new Button(this);lang.setText(english?"తెలుగు":"English");lang.setOnClickListener(v->{english=!english;build();});top.addView(lang);root.addView(top);
  TextView sub=text(english?"Plan tonight. Get reminded tomorrow.":"ఈ రాత్రే ప్లాన్ చేయండి. రేపు రిమైండర్ పొందండి.",14);sub.setPadding(0,dp(5),0,dp(16));root.addView(sub);
  title=new EditText(this);title.setSingleLine(true);title.setHint(english?"What do you need to do?":"ఏ పని చేయాలి?");root.addView(title,params());
  Button date=new Button(this);date.setText(english?"Choose date":"తేదీ ఎంచుకోండి");date.setOnClickListener(v->new DatePickerDialog(this,(view,y,m,d)->{chosen.set(y,m,d);date.setText(String.format(Locale.getDefault(),"%02d-%02d-%04d",d,m+1,y));},chosen.get(Calendar.YEAR),chosen.get(Calendar.MONTH),chosen.get(Calendar.DAY_OF_MONTH)).show());root.addView(date);
  Button time=new Button(this);time.setText(english?"Choose time":"సమయం ఎంచుకోండి");time.setOnClickListener(v->new TimePickerDialog(this,(view,h,m)->{chosen.set(Calendar.HOUR_OF_DAY,h);chosen.set(Calendar.MINUTE,m);chosen.set(Calendar.SECOND,0);time.setText(String.format(Locale.getDefault(),"%02d:%02d",h,m));},chosen.get(Calendar.HOUR_OF_DAY),chosen.get(Calendar.MINUTE),false).show());root.addView(time);
  Button add=new Button(this);add.setText(english?"＋ Save reminder":"＋ రిమైండర్ సేవ్ చేయి");add.setOnClickListener(v->addTask());root.addView(add);
  summary=text("",15);summary.setPadding(0,dp(18),0,dp(8));summary.setTypeface(null,Typeface.BOLD);root.addView(summary);
  list=new LinearLayout(this);list.setOrientation(1);root.addView(list);renderTasks();
 }
 LinearLayout.LayoutParams params(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);return p;}
 void addTask(){String s=title.getText().toString().trim();if(s.isEmpty()){title.setError(english?"Enter a task":"పని పేరు రాయండి");return;}if(chosen.getTimeInMillis()<=System.currentTimeMillis()){new AlertDialog.Builder(this).setMessage(english?"Choose a future time.":"భవిష్యత్తు సమయాన్ని ఎంచుకోండి.").setPositiveButton("OK",null).show();return;}
  try{String id=UUID.randomUUID().toString();JSONObject o=new JSONObject();o.put("id",id);o.put("title",s);o.put("when",chosen.getTimeInMillis());o.put("done",false);TaskStore.put(this,o);AlarmScheduler.schedule(this,id,chosen.getTimeInMillis());title.setText("");renderTasks();Toast.makeText(this,english?"Reminder saved":"రిమైండర్ సేవ్ అయింది",Toast.LENGTH_SHORT).show();}catch(Exception ignored){}
 }
 void renderTasks(){if(list==null)return;list.removeAllViews();List<JSONObject> tasks=TaskStore.all(this);int pending=0,done=0;for(JSONObject o:tasks){if(o.optBoolean("done"))done++;else pending++;}summary.setText((english?"PENDING: ":"పెండింగ్: ")+pending+"     "+(english?"COMPLETED: ":"పూర్తి: ")+done);
  tasks.sort((a,b)->Long.compare(a.optLong("when"),b.optLong("when")));
  for(JSONObject o:tasks){boolean isDone=o.optBoolean("done");LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(12),dp(10),dp(12),dp(8));card.setBackgroundColor(isDone?0xffe6f4ea:0xffffffff);LinearLayout.LayoutParams cp=params();cp.bottomMargin=dp(9);list.addView(card,cp);
   TextView name=text(o.optString("title"),17);name.setTypeface(null,Typeface.BOLD);card.addView(name);String when=new SimpleDateFormat("EEE, dd MMM yyyy • hh:mm a",Locale.getDefault()).format(new Date(o.optLong("when")));TextView meta=text(when+"   •   "+(isDone?(english?"Completed":"పూర్తయింది"):(english?"Pending":"పెండింగ్")),13);meta.setPadding(0,dp(4),0,dp(5));card.addView(meta);
   LinearLayout actions=new LinearLayout(this);if(!isDone){Button complete=new Button(this);complete.setText(english?"Mark done":"పూర్తయింది");complete.setOnClickListener(v->{try{o.put("done",true);TaskStore.put(this,o);AlarmScheduler.cancel(this,o.optString("id"));((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(o.optString("id").hashCode());renderTasks();}catch(Exception ignored){}});actions.addView(complete,new LinearLayout.LayoutParams(0,-2,1));}Button delete=new Button(this);delete.setText(english?"Delete":"తొలగించు");delete.setOnClickListener(v->{TaskStore.all(this).remove(o);List<JSONObject> all=TaskStore.all(this);all.removeIf(x->x.optString("id").equals(o.optString("id")));TaskStore.save(this,all);AlarmScheduler.cancel(this,o.optString("id"));renderTasks();});actions.addView(delete,new LinearLayout.LayoutParams(0,-2,1));card.addView(actions);
  }
 }
}
