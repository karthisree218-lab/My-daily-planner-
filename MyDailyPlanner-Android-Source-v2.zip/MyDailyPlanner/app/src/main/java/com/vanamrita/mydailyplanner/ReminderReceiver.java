package com.vanamrita.mydailyplanner;

import android.app.*;
import android.content.*;
import android.os.Build;
import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL="task_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        String id=intent.getStringExtra("id"); if(id==null)return;
        JSONObject task=TaskStore.find(context,id); if(task==null || task.optBoolean("done"))return;
        String title=task.optString("title","Task reminder");
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Task reminders",NotificationManager.IMPORTANCE_HIGH));
        Intent open=new Intent(context,MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(context,id.hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,CHANNEL):new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("Pending task / పెండింగ్ పని").setContentText(title).setStyle(new Notification.BigTextStyle().bigText(title+"\nMark it complete in My Daily Planner / Appలో పూర్తయినట్లు గుర్తించండి.")).setAutoCancel(true).setContentIntent(pi);
        nm.notify(id.hashCode(),b.build());
        // Repeat every 30 minutes until the task is marked complete.
        long next=System.currentTimeMillis()+30L*60L*1000L;
        AlarmScheduler.schedule(context,id,next);
    }
}
