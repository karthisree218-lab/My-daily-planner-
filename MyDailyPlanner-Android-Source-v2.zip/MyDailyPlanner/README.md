# My Daily Planner (Android source project)

Features:
- Add tasks with a date and exact time
- Local storage (tasks remain on the device)
- Pending and completed task counts
- Mark done / delete
- Reminder notification at scheduled time
- Repeats every 30 minutes until marked done
- Re-schedules pending reminders after device reboot
- English/Telugu UI toggle

## Build and install
1. Install Android Studio on a computer.
2. Open this `MyDailyPlanner` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Connect your Android phone with USB debugging enabled, or use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your phone.
6. Allow notifications. On Android 12+, allow exact alarms if the system asks.

## Important Android settings
- Keep notification permission enabled.
- Allow Alarms & reminders / exact alarms for this app when offered.
- Some phone manufacturers aggressively stop background alarms. Set battery usage for this app to Unrestricted / Don't optimize if reminders are delayed.

## Limitations
- This is a starter app project, not a signed APK. It must be built in Android Studio.
- Reminder repeat interval is fixed at 30 minutes.
- Data is stored locally; there is no cloud sync or backup.
